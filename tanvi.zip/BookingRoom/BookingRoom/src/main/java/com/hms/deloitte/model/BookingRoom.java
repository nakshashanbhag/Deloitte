package com.hms.deloitte.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="hr", name="bookingRoom")
public class BookingRoom {
	@Id
	private String customerUsername; 
	@Column
	private String checkIn;
	@Column
	private String checkOut;
	@Column
	private int numRoom;
	@Column
	private int noOfPeople;
	
	public BookingRoom() {
		// TODO Auto-generated constructor stub
	}
	
	public BookingRoom(String customerUsername, String checkIn, String checkOut, int numRoom, int noOfPeople) {
		super();
		this.customerUsername= customerUsername;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.numRoom = numRoom;
		this.noOfPeople = noOfPeople;
	}
	
	

	public String getCustomerUsername() {
		return customerUsername;
	}

	public void setCustomerUsername(String customerUsername) {
		this.customerUsername = customerUsername;
	}

	public String getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}

	public String getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}

	public int getnumRoom() {
		return numRoom;
	}

	public void setnumRoom(int numRoom) {
		this.numRoom = numRoom;
	}

	public int getNoOfPeople() {
		return noOfPeople;
	}

	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((checkIn == null) ? 0 : checkIn.hashCode());
		result = prime * result + ((checkOut == null) ? 0 : checkOut.hashCode());
		result = prime * result + noOfPeople;
		result = prime * result + numRoom;
		result = prime * result + ((customerUsername == null) ? 0 : customerUsername.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingRoom other = (BookingRoom) obj;
		if (checkIn == null) {
			if (other.checkIn != null)
				return false;
		} else if (!checkIn.equals(other.checkIn))
			return false;
		if (checkOut == null) {
			if (other.checkOut != null)
				return false;
		} else if (!checkOut.equals(other.checkOut))
			return false;
		if (noOfPeople != other.noOfPeople)
			return false;
		if (numRoom != other.numRoom)
			return false;
		if (customerUsername == null) {
			if (other.customerUsername != null)
				return false;
		} else if (!customerUsername.equals(other.customerUsername))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BookingRoom [customerUsername=" + customerUsername + ", checkIn=" + checkIn + ", checkOut=" + checkOut + ", noOfRoom="
				+ numRoom + ", noOfPeople=" + noOfPeople + "]";
	}

	
	
	

}
