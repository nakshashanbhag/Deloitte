package com.hms.deloitte.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hms.deloitte.model.StoringRoom;


@Repository
public interface StoringRoomDAO extends CrudRepository<StoringRoom, Integer> {
	public Optional<StoringRoom> findByRoomType(int roomType); 

}
