import java.util.*;
class treeset
{
public static void main(String args[])
{
TreeSet<String> treeset1 = new TreeSet<String>();
treeset1.add("Item 0");
treeset1.add("Item 1");
treeset1.add("Item 2");
treeset1.add("Item 3");
treeset1.add("Item 4");
treeset1.add("Item 6");
treeset1.add("Item 5");
System.out.println(treeset1);
}
}
