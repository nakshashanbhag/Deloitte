package testing;

public class Check1 {
	public static void main(String[] args) {
		String mod1=new String("The quick brown fox jumps over the lazy dog");
		String mod2=new String("The quick brown Fox jumps over the lazy Dog");
		System.out.println("Charecter at 12th index is :"+ mod1.charAt(12));
		
		if(mod1.contains("is"))
		{
			System.out.println("it contains is");
		}
		
		mod1= mod1.concat(" and killed it");
		System.out.println(mod1);
		
		if(mod1.endsWith("dogs"))
		{
			System.out.println("The given string ends with- dogs");
		}
		
		if(mod1.equalsIgnoreCase(mod2))
			System.out.println("Both the Strings are equal");
		
		mod2="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		
		if(mod1.equalsIgnoreCase(mod2))
			System.out.println("Both the Strings are equal");
		
		System.out.println("Lenght of the String is : "+mod1.length());
		
		if(mod1.matches("The quick brown Fox jumps over the lazy Dog"))
		{
			System.out.println("Statement matches");
		}
		
		mod1 = mod1.replace("the", "a");
		System.out.println("The modified String is "+mod1);
		
		//complete 10th and11th
		String s[]=mod1.split("jumps");
		
		System.out.println("Spl,itting Statements :");
		System.out.println("First part is"+s[0]);
		System.out.println("Second Part is"+s[1]);
		
		
		
		System.out.println("String in lower case  : " +mod1.toLowerCase());
		
		System.out.println("String in UpperCase : "+mod1.toUpperCase());
		
		System.out.println(mod1.indexOf('a'));
		
		System.out.println(mod1.lastIndexOf('e'));
		
	
	}
}
