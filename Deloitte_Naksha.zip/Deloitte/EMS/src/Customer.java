
public class Customer 
{
	public void customer()
	{
		System.out.println("Lets call customer class");
		Employee e = new Employee();
		e.employee();
	}
}
