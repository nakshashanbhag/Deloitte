package co.file;

import java.io.FileWriter;
import java.io.IOException;

public class Writing {

	public static void main(String[] args) throws IOException {
		FileWriter fw = new FileWriter("C:\\\\Deloitte\\\\Batch\\\\BatchBatchMates.txt" );
		fw.write("Hello,Welcome");
		fw.close();
		System.out.println("Demo done.");
	}
}
