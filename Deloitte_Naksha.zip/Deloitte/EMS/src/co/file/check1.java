package co.file;

import java.io.File;
import java.io.IOException;

public class check1 {
	public static void main(String[] args) throws IOException {
		
		File f1 = new File("C:\\Deloitte\\Batch");
		File f = new File("C:\\Deloitte\\Batch\\BatchBatchMates.txt");
		File f2 = new File("C:\\Deloitte\\Batch\\dummy");
		
		if(f.exists())
		{
			File allFiles[]= f1.listFiles();
			for(File temp: allFiles)
			{
				if(temp.isDirectory())
				{
					System.out.println(temp+ " is a directory");
				}
				else
					System.out.println(temp + " is a file");
			}
			
		}
		else
		{
			f1.mkdirs();
			f2.mkdir();
			f.createNewFile();
			System.out.println("File created");
		}
		
	}

}
