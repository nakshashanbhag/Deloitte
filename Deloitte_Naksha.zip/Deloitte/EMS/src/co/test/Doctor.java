package co.test;

public class Doctor {
	Practice p = new Practice();
	
	static int noOfObjects=0;
	
	
	
	static
	{
		System.out.println("fdf");
	}
	public Doctor() {
		noOfObjects+=1;
		System.out.println("default");
	}
	{
		System.out.println("f");
	}
	
	
	                                             
	public static void print()
	{
		System.out.println("Number of objects created are : " +noOfObjects);
	}
	
	public static void main(String[] args) {
		Doctor d1= new Doctor();
		new Doctor();
		
		Doctor.print();
		
	}

}
