package co.test;

public class Cat extends Animal {
	public void talk()

  {
	  System.out.println("Cat says Meow meo..");
  }
	
	public void eat()
	{
		System.out.println("Cat eats meat");
	}
	
}
