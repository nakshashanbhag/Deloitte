package co.test;

public class Practice {
	int i;
	public String nm;
	public Practice(){
		System.out.println("otyher constructor.");
		//System.out.println("i is : "+i);
	}
	
	public Practice(int num){
		i=num;
		System.out.println("Parameter constructor.");
		System.out.println("i is : "+i);
	}
	
	public Practice(String name)
	{	nm=name;
		System.out.println(nm);
	}
	
	
	public static void main(String[] args) {
		
		Practice p1 = new Practice();
		System.out.println(p1.i);
		
		Practice p2 = new Practice(10);
		System.out.println(p2.i);
		
		Practice p3= new Practice("Priyanka");
		System.out.println(p3.nm);
		
		Practice p4= new Practice("Chaithra");
		System.out.println(p4.nm);
		

		//
		System.out.println(p1.i);
		
		
	}

}

