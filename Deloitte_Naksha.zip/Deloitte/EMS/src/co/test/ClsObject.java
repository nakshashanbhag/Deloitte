package co.test;
class Employee
{
	int employeeId;
	String employeeName;
	public Employee(int employeeId, String employeeName) {
		//super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + "]";
	}
	
	
}

public class ClsObject {
	public static void main(String[] args) {
		Employee e1= new Employee(1,"equal");
		Employee e2= new Employee(1,"equal");
		
		System.out.println(e1.equals(e2));
		System.out.println(e1.toString());
		
		
	}

}
