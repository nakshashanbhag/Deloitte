package co.test;

public class Student {
	
	private int studentID;
	private String studentName;
	private int fees;
	private int marks;
	
	public Student() {
		this.studentID=0;
		this.studentName="NA";
		this.fees=10000;
		this.marks=35;
	
	}

	public Student(int studentID, String studentName, int fees) {
		this();
		this.studentID = studentID;
		this.studentName = studentName;
		this.fees = fees;
	}


	public Student(int studentID, String studentName) {
		this();
		this.studentID = studentID;
		this.studentName = studentName;
	}


	public Student(int studentID, int marks) {
		this();
		this.studentID = studentID;
		this.studentName = studentName;
		this.marks = marks;
	}

	
	
	//@Override
	public void print() {
		System.out.println( "Student [studentID=" + studentID + ", studentName=" + studentName + ", fees=" + fees + ", marks="
				+ marks + "]");
	}

	public static void main(String[] args) {
		Student s1= new Student();
		Student s2= new Student(123, "Jon", 50000);
		Student s3 = new Student(456, "Roy");
		Student s4 = new Student(789,"Taylor");
		
		s1.print();
		s2.print();
		s3.print();
		s4.print();
		
		
		
		
		
	}
	
	
	
}
