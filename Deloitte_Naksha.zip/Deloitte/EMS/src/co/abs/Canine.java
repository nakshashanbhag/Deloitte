package co.abs;

abstract class Canine extends Animal{
	abstract void makeNoise();
	abstract void eat();
	
	public void roam() {
		System.out.println("Canine Class animal roams");
	};

}

class Dog extends Canine
{
	public void makeNoise() {
		System.out.println("Dog Barks");
		
	}
	public void eat() {
		System.out.println("Dog eats boan");
	}
}

class Wolf extends Canine
{
	public void makeNoise() {}
	public void eat() {}
}

	
