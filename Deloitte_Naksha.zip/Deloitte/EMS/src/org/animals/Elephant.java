package org.animals;

public class Elephant {

	public String color="Black";
	public int weight=500;
	public int age=120;
	
	public void likeisVegetarian()
	{
		System.out.println("Elephant is a Vegetarian");
		
	}
	
	public void canClimb()
	{
		System.out.println("Elephant cannot climb");
		
	}
	
	public void getSound()
	{
		System.out.println("elphant sound");
	}
}
