package day6;

abstract class Vehicle1
{
	public abstract void method1();
}

class Car1 extends Vehicle1

{
	@Override
	public void method1() {
		System.out.println("Car started");
		
	}
	
}

class Bike extends Vehicle1

{
	@Override
	public void method1() {
		System.out.println("Bike started");
		
	}
	
}


public class VehicleApp2 {
	public static void main(String[] args) {
		Vehicle1 c1= new Car1();
		c1.method1();
	}
}
