package com.hms.deloitte.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hms.deloitte.model.StoringRoom;
import com.hms.deloitte.service.StoringRoomService;



@Controller

public class StoringRoomController {
	
	
	@Autowired
	private StoringRoomService storingRoomService;
	
	@RequestMapping(value = "/rooms")
	public String listRooms(Model model) {
	model.addAttribute("StoringRoom",new StoringRoom());
    model.addAttribute("listRooms",storingRoomService.listRooms());
	return "Storing";
	}
	
	@RequestMapping(value = "/incrementRooms/{roomType}")
	public String incrementRooms(@PathVariable("roomType") int roomType,Model model, StoringRoom storingRoom)
	{
		
		
		this.storingRoomService.incrementRoom(roomType);
		return "redirect:/rooms";
	}
	
	@RequestMapping(value = "/decrementRooms/{roomType}")
	public String decrementRooms(@PathVariable("roomType") int roomType,Model model, StoringRoom storingRoom)
	{	
		
		this.storingRoomService.decrementRoom(roomType);
		return "redirect:/rooms";
	}
	
		
}
