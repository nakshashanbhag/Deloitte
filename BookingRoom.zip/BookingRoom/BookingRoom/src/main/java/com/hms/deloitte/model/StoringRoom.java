package com.hms.deloitte.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema ="hr", name = "Storing1")

public class StoringRoom {
	
	
	@Id
	private int roomType;
	
	@Column
	private int price;
	
	@Column
	public int noOfRooms;
	
	
	@Column
	public int selected;
	
	@Column
	public int totalPrice;
	
	public StoringRoom() {
	
	}

	public StoringRoom(int roomType, int price, int noOfRooms, int selected, int totalPrice) {
		super();
		this.roomType = roomType;
		this.price = price;
		this.noOfRooms = noOfRooms;
		this.selected = selected;
		this.totalPrice = totalPrice;
	}

	public int getRoomType() {
		return roomType;
	}

	public void setRoomType(int roomType) {
		this.roomType = roomType;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getSelected() {
		return selected;
	}

	public void setSelected(int selected) {
		this.selected = selected;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + noOfRooms;
		result = prime * result + price;
		result = prime * result + roomType;
		result = prime * result + selected;
		result = prime * result + totalPrice;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StoringRoom other = (StoringRoom) obj;
		if (noOfRooms != other.noOfRooms)
			return false;
		if (price != other.price)
			return false;
		if (roomType != other.roomType)
			return false;
		if (selected != other.selected)
			return false;
		if (totalPrice != other.totalPrice)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StoringRoom [roomType=" + roomType + ", price=" + price + ", noOfRooms=" + noOfRooms + ", selected="
				+ selected + ", totalPrice=" + totalPrice + "]";
	}


}
