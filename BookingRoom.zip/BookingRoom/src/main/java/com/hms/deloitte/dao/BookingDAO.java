package com.hms.deloitte.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hms.deloitte.model.BookingRoom;

@Repository
public interface BookingDAO extends CrudRepository<BookingRoom, String>{

}
