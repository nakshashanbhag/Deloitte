package com.hms.deloitte.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hms.deloitte.dao.BookingDAO;
import com.hms.deloitte.model.BookingRoom;
@Controller
public class BRController {
	@Autowired
	BookingDAO bookingDAO;
	
	@RequestMapping("/saveBooking")
	public String saveBooking(Model model)
	{
		model.addAttribute("BookingRoom", new BookingRoom());
		return "bookingRoom";
	}
	@RequestMapping("/saveBookingRecord")
	public String saveBookingRecord(Model model, BookingRoom bookingRoom)
	{
		
		// String val = customerService.searchByCustomerUsername1(customerUsername);
		bookingDAO.save(bookingRoom);
		model.addAttribute("BookingRoom", new BookingRoom());
		return "bookingRoom";
	}

}
