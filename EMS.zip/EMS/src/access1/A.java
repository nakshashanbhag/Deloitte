package access1;

public class A {
	
	public int i;
	
	public void display()
	{
		A a = new A();
		a.i= 100;
		i=200;
	}
}
