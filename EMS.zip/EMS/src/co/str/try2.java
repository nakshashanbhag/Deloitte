package co.str;

import java.util.StringTokenizer;

public class try2 {
	public static void main(String[] args) {
		
	String quote1= "once:upon:a:time";	
	StringTokenizer tokenizer = new StringTokenizer(quote1,":");
	
	int len =  tokenizer.countTokens();
	
	String quoteRev[] =new String[len];
	
	int i=0;
	
	while(tokenizer.hasMoreTokens())
	{	
		
		quoteRev[i]=tokenizer.nextToken();
		//System.out.println("rev"+quoteRev[i]);
		
		i++;
	}
	
	
	for(i=len-1;i>=0;i--)
	System.out.println(quoteRev[i]);
	
	
}
}