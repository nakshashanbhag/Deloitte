package co.inter;

interface Radio
{
	abstract void play();
}

interface MusicPlayer
{
	abstract void songList();
}
interface newplayer extends Radio,MusicPlayer
{
	
}
class mob implements Radio,MusicPlayer{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void songList() {
		// TODO Auto-generated method stub
		
	}
	
}