package co.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import com.deloitte.myAppExceptions.InvalidCustomerIdExeption;
import com.deloitte.myAppExceptions.InvalidCustomerName;
import com.deloitte.myAppExceptions.NegativeBillAmountException;
public class tryList {
	public static void main(String[] args) throws NegativeBillAmountException, InvalidCustomerIdExeption, InvalidCustomerName {
		List<Customer> a = new ArrayList <Customer>();
		//TreeSet<Customer> a = new TreeSet <Customer>();
		Customer c1= new Customer(1,"jon","Pune",1000);
		Customer c2= new Customer(2,"Arya","Mumbai",2000);
		Customer c3= new Customer(3,"Tom","Delhi",3000);
		Customer c4= new Customer(4,"Sam","Bang",400);
		a.add(c1);
		a.add(c2);
		a.add(c3);
		a.add(c4);
		//a.add(1);
		System.out.println("Enter choices 1 for id , 2 for name, 3 for addrress, 4 for bill");
		Scanner sc = new Scanner(System.in);
		int opt = sc.nextInt();
		 switch(opt)
		 {
		 case 1 : Collections.sort(a,new CompId());
		 	System.out.println("hd");
		 			break;
		 case 2 : Collections.sort(a);
		 			
			break;
		
		 case 3 : Collections.sort(a,new CompAddress());
			break;
		
		 case 4 : Collections.sort(a,new CompBill());
			break;
		 }
		
		//Collections.sort(a);
		
		System.out.println(a);
		Iterator<Customer> item = a.iterator();
		System.out.println("Customer who has bill more than 2000 and are from delhi");
		
		while(item.hasNext())
		{
			Customer cust = item.next();
			if(cust.getBillAmount()>2000 && cust.getCustomerAddress()=="delhi")
				System.out.println(cust);
		}

		
		/*
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c3);
		System.out.println(c4);
		System.out.println(a.size());
		System.out.println(a.isEmpty());
		//System.out.println(a.sor););
		System.out.println(90+5);
		*/
	}

}
