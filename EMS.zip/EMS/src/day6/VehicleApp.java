package day6;

class Vehicle
{
	int modelName;
	static
	{
		System.out.println("1");
	}
	Vehicle() {
		System.out.println("Default constructer of Parent class\n");
	}
	public Vehicle(String carType) {
		System.out.println("Parameter constructer of Parent class"+carType);
	}
	
}

class Car extends Vehicle

{
	static
	{
		System.out.println("2");
	}
	public Car() {
		super("Calling parameter constructor "
				+ "");
		System.out.println("Default cons Child");
	}

	public Car(String carType) {
		super("\n call parent");
		System.out.println("para const Child :"+carType);
	}
	
}


public class VehicleApp {
	public static void main(String[] args) {
		Car c1= new Car();
		
	}
}
