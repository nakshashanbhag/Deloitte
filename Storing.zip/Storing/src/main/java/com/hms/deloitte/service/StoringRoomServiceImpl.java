package com.hms.deloitte.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hms.deloitte.dao.StoringRoomDAO;
import com.hms.deloitte.model.StoringRoom;



@Service
public class StoringRoomServiceImpl implements StoringRoomService{


	@Autowired
	StoringRoomDAO storingRoomDAO;

	@Override
	@Transactional
	public void incrementRoom(int roomType) {
		
		StoringRoom storingRoom = new StoringRoom();
		Optional<StoringRoom> storingRoom1 = storingRoomDAO.findByRoomType(roomType);
		
		storingRoom = storingRoom1.get();
		storingRoom.noOfRooms--;
	}

	@Override
	@Transactional
	public void decrementRoom(int roomType) {
		
		StoringRoom storingRoom = new StoringRoom();
		Optional<StoringRoom> storingRoom1 = storingRoomDAO.findByRoomType(roomType);
		
		storingRoom = storingRoom1.get();
		storingRoom.noOfRooms++;
	}
	@Override
	@Transactional
	public List<StoringRoom> listRooms() {
		return (List<StoringRoom>) this.storingRoomDAO.findAll();
		
	}
	

}
